import yaml
import streamlit as st
import streamlit_authenticator as stauth
from yaml.loader import SafeLoader


def load_authenticator() -> stauth.Authenticate:
    with open("config.yaml") as f:
        config = yaml.load(f, Loader=SafeLoader)

    return stauth.Authenticate(
        config["credentials"],
        config["cookie"]["name"],
        config["cookie"]["key"],
        config["cookie"]["expiry_days"],
    )


def require_login() -> bool:
    """Call at the top of main_window.py before rendering anything.
    Returns True if the user is authenticated, False otherwise."""
    authenticator = load_authenticator()

    name, authentication_status, username = authenticator.login("Login", "main")

    if authentication_status:
        # Show logout button in sidebar
        with st.sidebar:
            st.markdown(f"👤 **{name}**")
            authenticator.logout("Logout", "sidebar")
        return True

    elif authentication_status is False:
        st.error("Incorrect username or password.")
        return False

    else:
        st.info("Please enter your username and password.")
        return False
