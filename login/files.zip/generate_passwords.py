"""
Run this once to generate hashed passwords for your config.yaml.
Usage: python generate_passwords.py
"""
import streamlit_authenticator as stauth

# Add your users and plain-text passwords here
users = [
    {"username": "admin",   "name": "Admin User",  "password": "admin123"},
    {"username": "paul",    "name": "Paul K",       "password": "mypassword"},
]

hashed = stauth.Hasher([u["password"] for u in users]).generate()

print("Copy the following into your config.yaml:\n")
print("credentials:")
print("  usernames:")
for user, hashed_pw in zip(users, hashed):
    print(f"    {user['username']}:")
    print(f"      name: {user['name']}")
    print(f"      password: {hashed_pw}")
